from django.db import models


class Customer(models.Model):
    Customer_ID = models.CharField(max_length=100, primary_key=True)
    Company_Name = models.CharField(max_length=200)
    Main_Address = models.CharField(max_length=100)
    Primary_Contact = models.CharField(max_length=50)
    Primary_Phone = models.CharField(max_length=50)
    Customer_Type = models.CharField(max_length=50)
    Registration_Date = models.DateField()
    Services_Detail = models.CharField(max_length=100)

    def __str__(self):
        return self.Customer_ID

class LocationIdentifier(models.Model):
    Location_Identifier_ID = models.CharField(max_length=100, primary_key=True)
    Customer_ID = models.ForeignKey(Customer, on_delete=models.CASCADE)
    Branch_Name = models.CharField(max_length=100)
    Branch_Location = models.CharField(max_length=100)
    Specific_Location = models.IntegerField()

    def __str__(self):
        return self.Location_Identifier_ID

class DisplayDetail(models.Model):
    Display_ID = models.CharField(max_length=100, primary_key=True)
    Location_Identifier_ID = models.ForeignKey(LocationIdentifier, on_delete=models.CASCADE)
    #Hub_ID = models.ForeignKey(HubDetail, on_delete=models.CASCADE)
    Display_MAC = models.CharField(max_length=50)
    EPD_No = models.CharField(max_length=20)
    Activation_Date = models.DateField()
    Initial_IP = models.CharField(max_length=50)
    Current_IP = models.CharField(max_length=50)
    Is_Active = models.BooleanField()
    Display_Size = models.CharField(max_length=50)
    EPDs_Nos = models.CharField(max_length=20)
    Temp_Sensor = models.BooleanField()
    Humidity_Sensor = models.BooleanField()
    Presence_Sensor = models.BooleanField()
    Light_Sensor = models.BooleanField()
    BLE_Receiver = models.BooleanField()
    Memory_Size = models.CharField(max_length=50)
    LoRa_Comms = models.CharField(max_length=50)
    Wifi_Comms = models.CharField(max_length=50)
    Last_Message = models.CharField(max_length=50)
    Last_Image = models.CharField(max_length=50)

    def __str__(self):
        return self.Display_ID

class Messages(models.Model):
    Message_ID = models.CharField(max_length=50, primary_key=True)
    Location_Identifier_ID = models.ForeignKey(LocationIdentifier, on_delete=models.CASCADE)
    Date = models.DateField()
    Time = models.TimeField()
    Age = models.IntegerField()
    Gender = models.CharField(max_length=10)
    Message = models.CharField(max_length=50)
    Message_Parameters = models.CharField(max_length=50)
    Display_ID = models.ForeignKey(DisplayDetail, on_delete=models.CASCADE)
    def __str__(self):
        return self.Message_ID
    

class ViewerDetail(models.Model):
    Viewer_ID = models.CharField(max_length=50, primary_key=True)
    Location_Identifier_ID = models.ForeignKey(LocationIdentifier, on_delete=models.CASCADE)
    Gender = models.CharField(max_length=20)
    Age = models.IntegerField()
    Nationality = models.CharField(max_length=50)
    Course = models.CharField(max_length=50)
    Accommodation_Type = models.CharField(max_length=50)
    def _str_(self):
        return self.Viewer_ID


class StaffCustomer(models.Model):
    User_ID = models.CharField(max_length=100, primary_key=True)
    Location_Identifier_ID = models.ForeignKey(LocationIdentifier, on_delete=models.CASCADE)
    Username = models.CharField(max_length=50)
    Password = models.CharField(max_length=50)
    First_Name = models.CharField(max_length=50)
    Last_Name = models.CharField(max_length=50)
    Email = models.EmailField(max_length=50)
    Address = models.CharField(max_length=50)
    Phone = models.CharField(max_length=11)
    Initial_IP = models.CharField(max_length=50)
    Current_IP = models.CharField(max_length=50)
    Is_Active = models.BooleanField()

    def __str__(self):
        return self.User_ID

class FTPAddress(models.Model):
    FTP_Address = models.CharField(max_length=50, primary_key=True)
    Location_Identifier_ID = models.ForeignKey(LocationIdentifier, on_delete=models.CASCADE)
    Date = models.DateField()
    Time = models.TimeField()
    URL = models.CharField(max_length=100)  # Adjust the max_length as needed

    def __str__(self):
        return self.FTP_Address

class Images(models.Model):
    Image_ID = models.CharField(max_length=50, primary_key=True)
    FTP_Address = models.ForeignKey(FTPAddress, on_delete=models.CASCADE)
    Display_ID = models.ForeignKey(DisplayDetail, on_delete=models.CASCADE)
    Age = models.IntegerField()
    Gender = models.CharField(max_length=50)
    Image_Parameters = models.CharField(max_length=50)
    URL = models.CharField(max_length=100) 
    def __str__(self):
        return self.Image_ID

